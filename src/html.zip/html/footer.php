<?php 
ob_start();
session_start();
require_once 'setconfig.php';
 ?>
<footer class="footer text-center">
	Tüm Haklarımız Gizlidir. <a
	href="https://www.instagram.com/tolgahantrs/" target="_blank">Tolgahan Toros</a> Tarafından Oluşturulmuştur.
</footer>